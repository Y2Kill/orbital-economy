import { agent, agents, getPopulation } from "../Functions.js";
import { SPrimitive, SAgent, SPopulation } from "../Primitives.js";
import { fn } from "../CalcMap.js";
import { div, eq, evaluateNode, greaterThan, lessThan, minus, mult, PARENT_SYMBOL, plus, power, StringObject, toNum, trueValue, UserFunction, VectorObject } from "./Formula.js";
import { Rand, RandBeta, RandBinomial, RandDist, RandExp, RandGamma, RandLognormal, RandNegativeBinomial, RandNormal, RandPoisson, RandTriangular } from "./Rand.js";
import { Material, findSharedUnits } from "./Material.js";
import { convertUnits } from "./Units.js";
import { stringify, strictEquals } from "./Utilities.js";
import { Vector } from "./Vector.js";
import { ModelError } from "./ModelError.js";
import { jStat } from "../../vendor/jstat/jstat.js";
import { SeedRandom } from "../../vendor/random.js";
import { createUnitStore } from "../Modeler.js";


/**
 * @param {Material} mat
 * @param {import("./Units").UnitStore=} sharedUnits
 * @returns {number}
 */
function standardizedValue(mat, sharedUnits) {
  if (sharedUnits && mat.units !== sharedUnits) {
    return fn["*"](mat.value, convertUnits(mat.units, sharedUnits));
  }
  return mat.value;
}


/**
 * @param {import("../Simulator").Simulator} simulate
 */
export function createFunctions(simulate) {
  defineFunction(simulate, "RandBeta", { params: [{ name: "Alpha", noUnits: true, noVector: true }, { name: "Beta", noUnits: true, noVector: true }] }, (x) => {
    return new Material(RandBeta(simulate, x[0].value, x[1].value));
  });

  defineFunction(simulate, "RandDist", { params: [{ name: "Distribution", needVector: true }, { name: "Y (in which case Distribution is X)", noUnits: true, needVector: true, defaultVal: false }] }, (x) => {
    let xMats, yMats;
    if (x.length === 1 || x[1] === false) {
      let vec = x[0];
      xMats = [];
      yMats = [];
      for (let i = 0; i < vec.items.length; i++) {
        if (!(vec.items[i] instanceof Vector) || vec.items[i].items.length !== 2) {
          throw new ModelError("Invalid vector provided to RandDist.", {
            code: 6000
          });
        }
        xMats.push(toNum(vec.items[i].items[0]));
        yMats.push(toNum(vec.items[i].items[1]));
      }
    } else {
      xMats = toNum(x[0]).items.map(z => toNum(z));
      yMats = toNum(x[1]).items.map(z => toNum(z));
    }

    for (let m of yMats) {
      if (m && m.units && !m.units.isUnitless()) {
        throw new ModelError(`RandDist does not accept units for the Y values. Got units of <i>${m.units.toString()}</i>.`, {
          code: 6063
        });
      }
    }

    let { units: sharedUnits, explicitUnits } = findSharedUnits(xMats);
    let xVals = xMats.map(m => standardizedValue(m, sharedUnits));
    let yVals = yMats.map(m => m.value);

    let result = new Material(RandDist(simulate, xVals, yVals));
    if (sharedUnits) {
      result.units = sharedUnits;
      result.explicitUnits = explicitUnits;
    }
    return result;
  });

  defineFunction(simulate, "RandBoolean", { params: [{ name: "Probability", defaultVal: 0.5, noUnits: true, vectorize: true }] }, (x) => {
    let p;
    if (x.length !== 0) {
      p = toNum(x[0]).value;
    } else {
      p = 0.5;
    }

    if (Rand(simulate) < p) {
      return true;
    } else {
      return false;
    }
  });
  defineFunction(simulate, "Rand", { params: [{ name: "Lower Bound", defaultVal: 0, vectorize: true }, { name: "Upper Bound", defaultVal: 1, vectorize: true }] }, (x) => {
    if (x.length === 0) {
      return new Material(Rand(simulate));
    } else if (x.length === 2) {
      let lower = toNum(x[0]);
      let upper = toNum(x[1]);
      let { units: sharedUnits, explicitUnits } = findSharedUnits([lower, upper]);
      let result = new Material(Rand(simulate, standardizedValue(lower, sharedUnits), standardizedValue(upper, sharedUnits)));
      if (sharedUnits) {
        result.units = sharedUnits;
        result.explicitUnits = explicitUnits;
      }
      return result;
    } else {
      throw new ModelError("Rand() must either have no parameters or two: Min and Max bounds.", {
        code: 6001
      });
    }
  });
  defineFunction(simulate, "RandNormal", { params: [{ name: "Mean", defaultVal: 0, noUnits: true, vectorize: true }, { name: "Standard Deviation", defaultVal: 1, noUnits: true, vectorize: true }] }, (x) => {
    if (x.length === 0) {
      return new Material(RandNormal(simulate));
    } else if (x.length === 2) {
      return new Material(RandNormal(simulate, toNum(x[0]).value, toNum(x[1]).value));
    } else {
      throw new ModelError("RandNormal() must either have no parameters or two: Mean and Standard Deviation.", {
        code: 6002
      });
    }
  });
  defineFunction(simulate, "RandExp", { params: [{ name: "Rate", defaultVal: 1, noUnits: true, vectorize: true }] }, (x) => {
    if (x.length !== 0) {
      return new Material(RandExp(simulate, toNum(x[0]).value));
    } else {
      return new Material(RandExp(simulate));
    }
  });
  defineFunction(simulate, "RandLognormal", { params: [{ name: "Mean", noUnits: true, vectorize: true }, { name: "Standard Deviation", noUnits: true, vectorize: true }] }, (x) => {
    return new Material(RandLognormal(simulate, toNum(x[0]).value, toNum(x[1]).value));
  });
  defineFunction(simulate, "RandBinomial", { params: [{ name: "Count", noUnits: true, vectorize: true }, { name: "Probability", noUnits: true, vectorize: true }] }, (x) => {
    return new Material(RandBinomial(simulate, toNum(x[0]).value, toNum(x[1]).value));
  });
  defineFunction(simulate, "RandNegativeBinomial", { params: [{ name: "Successes", noUnits: true, vectorize: true }, { name: "Probability", noUnits: true, vectorize: true }] }, (x) => {
    return new Material(RandNegativeBinomial(simulate, toNum(x[0]).value, toNum(x[1]).value));
  });
  defineFunction(simulate, "RandGamma", { params: [{ name: "Alpha", noUnits: true, vectorize: true }, { name: "Beta", noUnits: true, vectorize: true }] }, (x) => {
    return new Material(RandGamma(simulate, toNum(x[0]).value, toNum(x[1]).value));
  });
  defineFunction(simulate, "RandPoisson", { params: [{ name: "Rate", noUnits: true, vectorize: true }] }, (x) => {
    return new Material(RandPoisson(simulate, toNum(x[0]).value));
  });
  defineFunction(simulate, "RandTriangular", { params: [{ name: "Minimum", vectorize: true }, { name: "Maximum", vectorize: true }, { name: "Peak", vectorize: true }] }, (x) => {
    let min = toNum(x[0]);
    let max = toNum(x[1]);
    let peak = toNum(x[2]);
    let { units: sharedUnits, explicitUnits } = findSharedUnits([min, max, peak]);
    let result = new Material(RandTriangular(simulate, standardizedValue(min, sharedUnits), standardizedValue(max, sharedUnits), standardizedValue(peak, sharedUnits)));
    if (sharedUnits) {
      result.units = sharedUnits;
      result.explicitUnits = explicitUnits;
    }
    return result;
  });

  defineFunction(simulate, "Magnitude", { params: [{ name: "Vector", needVector: true }], complete: false }, (x) => {
    return simulate.coreBank.get("sqrt")([simulate.coreBank.get("sum")([mult(x[0], x[0])])]);
  });



  defineFunction(simulate, "Abs", { params: [{ name: "Number", leafNeedNum: true }], recurse: true }, (x) => {
    let r = toNum(x[0]);
    r.value = fn.abs(r.value);
    return r;
  });
  defineFunction(simulate, "sin", { params: [{ name: "Number", leafNeedNum: true }], recurse: true}, (x) => {
    let z = toNum(x[0]);

    if (z.units && !z.units.isUnitless()) {
      z = mult(z, new Material(1, simulate.unitManager.getUnitStore(["radians"], [-1])));
    }
    if (!z.units) {
      return new Material(fn.sin(z.value));
    } else {
      throw new ModelError("Non-angular units cannot be used in Sin().", {
        code: 6003
      });
    }
  });
  defineFunction(simulate, "cos", { params: [{ name: "Number", leafNeedNum: true }], recurse: true }, (x) => {
    let z = toNum(x[0]);

    if (z.units && !z.units.isUnitless()) {
      z = mult(z, new Material(1, simulate.unitManager.getUnitStore(["radians"], [-1])));
    }
    if (!z.units) {
      return new Material(fn.cos(z.value));
    } else {
      throw new ModelError("Non-angular units cannot be used in Cos().", {
        code: 6004
      });
    }
  });
  defineFunction(simulate, "tan", { params: [{ name: "Number", leafNeedNum: true }], recurse: true }, (x) => {
    let z = toNum(x[0]);

    if (z.units && !z.units.isUnitless()) {
      z = mult(z, new Material(1, simulate.unitManager.getUnitStore(["radians"], [-1])));
    }
    if (!z.units) {
      return new Material(fn.tan(z.value));
    } else {
      throw new ModelError("Non-angular units cannot be used in Tan().", {
        code: 6005
      });
    }
  });
  defineFunction(simulate, "asin", { params: [{ name: "Number", noUnits: true, leafNeedNum: true }], recurse: true, complete: false }, (x) => {

    let val = toNum(x[0]).value;
    if (val < -1 || val > 1) {
      throw new ModelError("asin() input must be between -1 and 1.", {
        code: 6077
      });
    }

    return new Material(fn.asin(val));
  });
  defineFunction(simulate, "acos", { params: [{ name: "Number", noUnits: true, leafNeedNum: true }], recurse: true, complete: false }, (x) => {
    let val = toNum(x[0]).value;
    if (val < -1 || val > 1) {
      throw new ModelError("acos() input must be between -1 and 1.", {
        code: 6078
      });
    }

    return new Material(fn.acos(val));
  });
  defineFunction(simulate, "atan", { params: [{ name: "Number", noUnits: true, leafNeedNum: true }], recurse: true, complete: false }, (x) => {
    return new Material(fn.atan(toNum(x[0]).value));
  });

  defineFunction(simulate, "arcsin", { params: [{ name: "Number", noUnits: true, leafNeedNum: true }], recurse: true }, (x) => {
    let val = toNum(x[0]).value;
    if (val < -1 || val > 1) {
      throw new ModelError("arcsin() input must be between -1 and 1.", {
        code: 6077
      });
    }

    return new Material(fn.asin(val), simulate.unitManager.getUnitStore(["radians"], [1]), false);
  });
  defineFunction(simulate, "arccos", { params: [{ name: "Number", noUnits: true, leafNeedNum: true }], recurse: true }, (x) => {
    let val = toNum(x[0]).value;
    if (val < -1 || val > 1) {
      throw new ModelError("arccos() input must be between -1 and 1.", {
        code: 6078
      });
    }

    return new Material(fn.acos(val), simulate.unitManager.getUnitStore(["radians"], [1]), false);
  });
  defineFunction(simulate, "arctan", { params: [{ name: "Number", noUnits: true, leafNeedNum: true }], recurse: true }, (x) => {
    return new Material(fn.atan(toNum(x[0]).value), simulate.unitManager.getUnitStore(["radians"], [1]), false);
  });

  defineFunction(simulate, "Sign", { params: [{ name: "Number", leafNeedNum: true }], recurse: true }, (x) => {
    let r = toNum(x[0]);
    if (r.value < 0) {
      return new Material(-1);
    } else if (r.value > 0) {
      return new Material(1);
    } else if (r.value === 0) {
      return new Material(0);
    }
    throw new ModelError("Invalid value for <i>Sign</i>.", {
      code: 6006
    });
  });
  defineFunction(simulate, "Sqrt", { params: [{ name: "Number", leafNeedNum: true }], recurse: true }, (x) => {
    let r = toNum(x[0]).fullClone();
    if (r.value < 0) {
      throw new ModelError("Sqrt() requires a number greater than or equal to 0.", {
        code: 6007
      });
    }
    r.value = fn.sqrt(r.value);
    if (r.units && !r.units.isUnitless()) {
      r.units = r.units.power(0.5);
    }
    return r;
  });
  defineFunction(simulate, "Ln", { params: [{ name: "Number", noUnits: true, leafNeedNum: true }], recurse: true }, (x) => {
    let val = toNum(x[0]).value;
    if (val < 0) {
      throw new ModelError("Ln() requires a number greater than or equal to 0. Got, <i>" + val + "</i>.", {
        code: 6008
      });
    }
    return new Material(fn.log(val));
  });
  defineFunction(simulate, "Log", { params: [{ name: "Number", noUnits: true, leafNeedNum: true }], recurse: true }, (x) => {
    let val = toNum(x[0]).value;
    if (val < 0) {
      throw new ModelError("Log() requires a number greater than or equal to 0. Got, <i>" + val + "</i>.", {
        code: 6009
      });
    }
    return new Material(fn.log(val, 10));
  });
  defineFunction(simulate, "Logit", { params: [{ name: "Number", noUnits: true, leafNeedNum: true }], recurse: true }, (x) => {
    let r = toNum(x[0]);

    if (r.value < 0 || r.value > 1) {
      throw new ModelError("Logit() requires an input between 0 and 1 (inclusive).", {
        code: 6079
      });
    }

    r.value = fn["-"](fn.log(r.value), fn.log(fn["-"](1, r.value)));
    return r;
  });
  defineFunction(simulate, "Expit", { params: [{ name: "Number", noUnits: true, leafNeedNum: true }], recurse: true }, (x) => {
    let r = toNum(x[0]);
    r.value = fn["/"](1, fn["+"](1, fn.exp(fn["-"](r.value))));
    return r;
  });
  defineFunction(simulate, "Round", { params: [
    { name: "Number", noUnits: false, leafNeedNum: true },
    { name: "Units", needString: true, defaultVal: "<DETECTED>", silentDefault: true }
  ], recurse: true }, (x) => {
    /** @type {Material} */
    let r = toNum(x[0]);

    if (!x[1]) {
      if (r.units && !r.explicitUnits && !r.units.isDeepUnitless()) {
        throw new ModelError("Round() requires either no units or units that have been explicitly set. Got: " + r.units.toString() + ". If those units are correct, try <b>round(number, \"" + r.units.toStringShort() + "\")</b>", {
          code: 6463
        });
      }
    } else {
      r = r.forceUnits(createUnitStore(x[1], simulate));
    }


    r.value = fn.round(r.value);
    return r;
  });
  defineFunction(simulate, "Ceiling", { params: [
    { name: "Number", noUnits: false, leafNeedNum: true },
    { name: "Units", needString: true, defaultVal: "<DETECTED>", silentDefault: true }
  ], recurse: true }, (x) => {
    /** @type {Material} */
    let r = toNum(x[0]);

    if (!x[1]) {
      if (r.units && !r.explicitUnits && !r.units.isDeepUnitless()) {
        throw new ModelError("Ceiling() requires either no units or units that have been explicitly set. Current units are " + r.units.toString() + ". If those units are correct, try <b>ceiling(number, \"" + r.units.toStringShort() + "\")</b>", {
          code: 6464
        });
      }
    } else {
      r = r.forceUnits(createUnitStore(x[1], simulate));
    }

    r.value = fn.ceiling(r.value);
    return r;
  });
  defineFunction(simulate, "Floor", { params: [
    { name: "Number", noUnits: false, leafNeedNum: true },
    { name: "Units", needString: true, defaultVal: "<DETECTED>", silentDefault: true }
  ], recurse: true }, (x) => {
    /** @type {Material} */
    let r = toNum(x[0]);

    if (!x[1]) {
      if (r.units && !r.explicitUnits && !r.units.isDeepUnitless()) {
        throw new ModelError("Floor() requires either no units or units that have been explicitly set. Got: " + r.units.toString() + ". If those units are correct, try <b>floor(number, \"" + r.units.toStringShort() + "\")</b>", {
          code: 6462
        });
      }
    } else {
      r = r.forceUnits(createUnitStore(x[1], simulate));
    }

    r.value = fn.floor(r.value);
    return r;
  });
  defineFunction(simulate, "Exp", { params: [{ name: "Number", noUnits: true, leafNeedNum: true }], recurse: true }, (x) => {
    return new Material(fn.exp(toNum(x[0]).value));
  });

  simulate.varBank.set("ifthenelse", (x) => {
    testArgumentsSize(x, "IfThenElse", 3, 3);

    let v = toNum(evaluateNode(x[0].node, x[0].scope, simulate));

    if (v instanceof Vector) {
      return vecIfThenElse(v, evaluateNode(x[1].node, x[1].scope, simulate), evaluateNode(x[2].node, x[2].scope, simulate));
    }

    if (trueValue(v)) {
      return evaluateNode(x[1].node, x[1].scope, simulate);
    } else {
      return evaluateNode(x[2].node, x[2].scope, simulate);
    }
  });
  simulate.varBank.get("ifthenelse").delayEvalParams = true;
  simulate.coreBank.set("ifthenelse", simulate.varBank.get("ifthenelse"));
  setFunctionDef("IfThenElse", {
    params: [
      { name: "Condition" },
      { name: "If True" },
      { name: "If False" }
    ]
  });


  simulate.varBank.set("assert", (x) => {
    testArgumentsSize(x, "Assert", 1, 2);

    let v = evaluateNode(x[0].node, x[0].scope, simulate);

    if (!trueValue(v)) {
      throw new ModelError(x[1] ? evaluateNode(x[1].node, x[1].scope, simulate) : "Assert() failed", {
        code: 20000
      });
    } else {
      return new Material(1);
    }
  });
  simulate.varBank.get("assert").delayEvalParams = true;
  simulate.coreBank.set("assert", simulate.varBank.get("assert"));
  setFunctionDef("Assert", {
    params: [
      { name: "Condition" },
      { name: "Message", defaultVal: "'Assert() failed'", allowString: true }
    ]
  });

  function vecIfThenElse(test, tVal, fVal) {

    let choiceFn = function (t, f) {
      if (t instanceof Vector) {
        return t.combine(f, choiceFn);
      } else {
        return [t, f];
      }
    };

    tVal = toNum(tVal);
    fVal = toNum(fVal);
    let choices;
    if (tVal instanceof Vector) {
      choices = tVal.cloneCombine(fVal, choiceFn);
    } else if (fVal instanceof Vector) {
      choices = fVal.cloneCombine(tVal, (a, b) => {
        return choiceFn(b, a);
      });
    } else {
      choices = choiceFn(tVal, fVal);
    }

    let testFn = function (test, val) {
      if (test instanceof Vector) {
        return test.combine(val, testFn);
      }

      if (!Array.isArray(val)) {
        throw new ModelError("Keys do not match for vectorized IfThenElse().", {
          code: 6093
        });
      }

      if (trueValue(test)) {
        return val[0];
      } else {
        return val[1];
      }
    };

    return test.cloneCombine(choices, testFn);
  }


  simulate.varBank.set("map", (x) => {
    testArgumentsSize(x, "Map", 2, 2);
    let v;
    if (x[0].node instanceof Vector) {
      v = x[0].node;
    } else if (x[0] instanceof Vector) {
      v = x[0];
    } else {
      v = evaluateNode(x[0].node, x[1].scope, simulate);
    }

    if (v instanceof SPrimitive) {
      v = toNum(v);
    }
    if (!(v instanceof Vector)) {
      throw new ModelError("Map() requires a vector as its first argument.", {
        code: 6010
      });
    }
    v = v.fullClone();

    let fn;
    /** @type {Array} */
    let items = [
      [PARENT_SYMBOL, x[1].scope],
      ["x", null],
    ];
    let scope = new Map(items);
    let node = x[1].node;
    try {
      fn = evaluateNode(node, scope, simulate);
    } catch (err) {
      // pass
    }

    let f;
    if (fn instanceof Function || fn instanceof UserFunction) {
      if (fn.fn) {
        fn = fn.fn;
      }
      f = function (x) {
        return fn([x]);
      };
    } else {
      f = function (input, key) {
        scope.set("x", input);
        scope.set("key", key || "");
        return evaluateNode(node, scope, simulate);
      };
    }

    return v.apply(f);
  });
  simulate.varBank.get("map").delayEvalParams = true;
  setFunctionDef("Map", {
    object: [simulate.varBank, VectorObject],
    params: [
      { name: "Vector" },
      {
        name: "Function",
        implicitFunction: true,
        injectedVariables: [
          { name: "x" },
          { name: "key" }
        ]
      }
    ]
  });
  VectorObject["map"] = simulate.varBank.get("map");
  simulate.coreBank.set("map", simulate.varBank.get("map"));

  defineFunction(simulate, "Sample", { object: [simulate.varBank, VectorObject], params: [{ name: "Vector", needVector: true }, { name: "Sample Size", noUnits: true, noVector: true }, { name: "Repeat", noVector: true, allowBoolean: true, defaultVal: false }] }, (x) => {
    let v = toNum(x[0]);
    let count = toNum(x[1]).value;
    if (count === 0) {
      return new Vector([], simulate);
    }

    let length = v.length();
    let repeat = x[2] && trueValue(toNum(x[2]));

    if (length === 0) {
      throw new ModelError("Sample() requires a non-empty vector.", {
        code: 6011
      });
    }

    if (count < 0) {
      throw new ModelError("Sample size in Sample() must be greater than or equal to 0.", {
        code: 6081
      });
    }

    let res = [];
    if (repeat) {
      for (let i = 0; i < count; i++) {
        res.push(v.items[Math.floor(Rand(simulate) * length)]);
      }
    } else {
      if (length < count) {
        throw new ModelError("Vector for Sample() is too small for the given sample size.", {
          code: 6012
        });
      }

      let shuffled = v.items.slice();
      for (let i = 0; i < count; i++) {
        res.push(shuffled.splice(Math.floor(Rand(simulate) * shuffled.length), 1)[0]);
      }
    }

    return new Vector(res, simulate);
  });

  defineFunction(simulate, "IndexOf", { object: [simulate.varBank, VectorObject], params: [{ name: "Haystack", needVector: true }, { name: "Needle", allowBoolean: true, allowString: true }] }, (x) => {

    let v = x[1];

    if (v instanceof Vector) {
      let res = [];
      for (let i = 0; i < v.items.length; i++) {
        res.push(findElement(v.items[i], x[0]));
      }
      return new Vector(res, simulate);
    } else {
      return findElement(v, x[0]);
    }
  });

  defineFunction(simulate, "Contains", { object: [simulate.varBank, VectorObject], params: [
    { name: "Haystack", needVector: true },
    { name: "Needle", allowBoolean: true, noVector: true, allowString: true }
  ] }, (x) => {
    if (eq(
      new Material(0),
      simulate.coreBank.get("indexof")([new Vector(flatten(x[0]).items, simulate), x[1]])
    )) {
      return false;
    } else {
      return true;
    }
  });

  defineFunction(simulate, "Collapse", {
    params: [{ name: "Source", needVector: true }, { name: "Target", noVector: false }],
    complete: false
  }, (x) => {
    return toNum(x[0]).collapseDimensions(toNum(x[1]));
  });

  function findElement(needle, haystack) {
    for (let i = 0; i < haystack.length(); i++) {
      if (eq(needle, haystack.items[i])) {
        return new Material(i + 1);
      }
    }
    return new Material(0);
  }

  simulate.varBank.set("filter", (x) => {
    testArgumentsSize(x, "Filter", 2, 2);

    let v;
    if (x[0].node instanceof Vector) {
      v = x[0].node;
    } else if (x[0] instanceof Vector) {
      v = x[0];
    } else {
      v = evaluateNode(x[0].node, x[0].scope, simulate);
    }

    if (v instanceof SPrimitive) {
      v = toNum(v);
    }
    if (!(v instanceof Vector)) {
      throw new ModelError("Filter() requires a vector as its first argument.", {
        code: 6013
      });
    }
    v = v.fullClone();

    let t = simulate.coreBank.get("map")(x);
    return simulate.coreBank.get("select")([v, t]);
  });
  simulate.varBank.get("filter").delayEvalParams = true;
  setFunctionDef("Filter", {
    object: [simulate.varBank, VectorObject],
    params: [
      { name: "Vector" },
      {
        name: "Function",
        implicitFunction: true,
        injectedVariables: [
          { name: "x" },
          { name: "key" }
        ]
      }
    ]
  });
  VectorObject["filter"] = simulate.varBank.get("filter");
  simulate.coreBank.set("filter", simulate.varBank.get("filter"));

  simulate.varBank.set("join", (x) => {
    let res = [];
    let names = [];
    let hasNames = false;
    for (let i = 0; i < x.length; i++) {
      let y = x[i];

      if (y instanceof SPrimitive) {
        y = toNum(y);
      }

      if (y instanceof Vector) {
        res = res.concat(y.items);
        if (y.names) {
          names = names.concat(y.names);
          hasNames = true;
        } else {
          for (let j = 0; j < y.items.length; j++) {
            names.push(undefined);
          }
        }
      } else {
        res.push(y);
        names.push(undefined);
      }
    }
    return new Vector(res, simulate, hasNames ? names : undefined);
  });
  simulate.coreBank.set("join", simulate.varBank.get("join"));
  setFunctionDef("Join", {
    allowEmpty: true,
    param: { name: "Items..." }
  });

  simulate.varBank.set("repeat", (x) => {
    testArgumentsSize(x, "Repeat", 2, 2);
    let items = toNum(evaluateNode(x[1].node, x[1].scope, simulate));
    let count = items;
    if (items instanceof Vector) {
      if (items.names && items.names.length) {
        throw new ModelError(`If a repeat count is a vector, it can't have names. Got, <i>${items}</i>.`, {
          code: 6070
        });
      }

      let innerItems = items.items;
      if (innerItems.find(x => !(typeof x === "string" || x instanceof String))) {
        throw new ModelError(`If a repeat count is a vector, it must consist of all strings. Got, <i>${items}</i>.`, {
          code: 6071
        });
      }

      if (new Set(innerItems).size !== innerItems.length) {
        throw new ModelError(`If a repeat count is a vector, it must contain unique strings. Got, <i>${items}</i>.`, {
          code: 6072
        });
      }

      count = items.items.length;
    } else if (items instanceof Material) {
      if (items.units && !items.units.isUnitless()) {
        throw new ModelError(`Repeat count must be unitless. Got, <i>${items}</i>.`, {
          code: 6073
        });
      }

      if (items.value < 0) {
        throw new ModelError(`Repeat count must be a non-negative. Got, <i>${items.value}</i>.`, {
          code: 6075
        });
      }
    } else {
      throw new ModelError(`Repeat count must be a Number or Vector. Got, <i>${items}</i>.`, {
        code: 6074
      });
    }

    let res = [];

    /** @type {Array} */
    let scopeItems = [
      ["x", null],
      [PARENT_SYMBOL, x[1].scope],
      ["key", null]
    ];
    let scope = new Map(scopeItems);
    for (let i = 0; i < count; i++) {
      if (items instanceof Vector) {
        scope.set("key", items.items[i]);
      }
      scope.set("x", new Material(i + 1));
      res.push(evaluateNode(x[0].node, scope, simulate));
    }

    return new Vector(res, simulate, items instanceof Vector ? items.items.slice() : undefined);
  });
  simulate.varBank.get("repeat").delayEvalParams = true;
  setFunctionDef("Repeat", {
    params: [
      {
        name: "Expression",
        implicitFunction: true,
        injectedVariables: [
          { name: "x" },
          { name: "key" }
        ]
      },
      {
        name: "Times"
      }
    ]
  });
  simulate.coreBank.set("repeat", simulate.varBank.get("repeat"));

  defineFunction(simulate, "Select", { params: [{ name: "Haystack", needVector: true }, { name: "Indexes", noUnits: true }] }, (x) => {
    if (x[1] instanceof Vector) {
      let v = toNum(x[1]);
      let isBoolean = true;
      for (let i = 0; i < v.length(); i++) {
        if (v.items[i] instanceof Material) {
          isBoolean = false;
          break;
        }
      }
      if (isBoolean === true) {
        let res = [];
        let names = x[0].names ? /** @type {string[]} */ ([]) : undefined;
        if (v.length() !== x[0].length()) {
          throw new ModelError("Length of vector must be equal for boolean selection.", {
            code: 6014
          });
        }
        for (let i = 0; i < v.length(); i++) {
          if (trueValue(v.items[i])) {
            res.push(x[0].items[i]);

            if (names) {
              names.push(x[0].names[i]);
            }
          }
        }
        return new Vector(res, simulate, names);
      } else {
        let res = [];
        let names = x[0].names ? /** @type {string[]} */ ([]) : undefined;
        for (let i = 0; i < v.length(); i++) {
          let q = v.items[i].value;
          if (q <= 0 || q > x[0].length()) {
            let msg = "Selected element out of range.";

            if (q === 0) {
              msg += " Vector indexes are 1-based, so the first element is selected with 1.";
            }


            throw new ModelError(msg, {
              code: 6015
            });
          } else if (Math.floor(q) !== q) {
            throw new ModelError("Selected element must be an integer.", {
              code: 6015
            });
          }
          res.push(x[0].items[q - 1]);

          if (names) {
            names.push(x[0].names[q - 1]);
          }
        }
        return new Vector(res, simulate, names);
      }
    } else {
      if (Math.floor(x[1].value) !== x[1].value) {
        throw new ModelError("Selected element must be an integer.", {
          code: 6016
        });
      } else if (x[1].value > 0 && x[1].value <= x[0].length()) {
        return x[0].items[x[1].value - 1];
      } else {
        let msg = "Selected element out of range.";

        if (x[1].value === 0) {
          msg += " Vector indexes are 1-based, so the first element is selected with 1.";
        }

        throw new ModelError(msg, {
          code: 6016
        });
      }
    }
  });

  defineFunction(simulate, "Reverse", {
    allowEmpty: true, param: { name: "Items..." }, prep: function (x) {
      return simulate.coreBank.get("join")(x);
    }
  }, (x) => {
    return new Vector(x.items.slice().reverse(), simulate, x.names ? x.names.slice().reverse() : undefined);
  });
  defineFunction(simulate, "Reverse", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    return simulate.coreBank.get("reverse")(x);
  });

  defineFunction(simulate, "Sort", {
    allowEmpty: true, param: { name: "Items..." }, prep: function (x) {
      return toNum(simulate.coreBank.get("join")(x));
    }
  },
  /**
     * @param {Vector} x
     * @returns
     */
  (x) => {
    let res = x.stackApply((x) => {
      let items = [];
      for (let i = 0; i < x.items.length; i++) {
        items.push({ item: x.items[i], name: x.names ? x.names[i] : undefined });
      }

      let res = items.sort((a, b) => {
        if (lessThan(a.item, b.item)) {
          return -1;
        }
        if (greaterThan(a.item, b.item)) {
          return 1;
        }
        return 0;
      });


      let names = x.names ? /** @type {string[]} */ ([]) : undefined;
      items = [];

      for (let i = 0; i < res.length; i++) {
        items.push(res[i].item);
        if (names) {
          names.push(/** @type {string} */ (res[i].name));
        }
      }

      return new Vector(items, simulate, names);
    });

    return res;
  });
  defineFunction(simulate, "Sort", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    return simulate.coreBank.get("sort")(x);
  });

  defineFunction(simulate, "Unique", {
    allowEmpty: true, param: { name: "Items...", allowBoolean: true }, prep: function (x) {
      return toNum(simulate.coreBank.get("join")(x));
    }
  }, (x) => {
    if (!x.items.length) {
      return new Vector([], simulate);
    }

    let res = [];
    let names = x.names ? /** @type {string[]} */ ([]) : undefined;

    for (let i = 0; i < x.items.length; i++) {
      let found = false;

      for (let j = 0; j < res.length; j++) {
        if (strictEquals(x.items[i], res[j])) {
          found = true;
          break;
        }
      }
      if (!found) {
        res.push(x.items[i]);
        if (names) {
          names.push(x.names[i]);
        }
      }
    }

    return new Vector(res, simulate, names);
  });
  defineFunction(simulate, "Unique", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    return simulate.coreBank.get("unique")(x);
  });


  defineFunction(simulate, "Union", { object: [simulate.varBank, VectorObject], params: [{ name: "Vector 1", needVector: true }, { name: "Vector 2", needVector: true }] }, (x) => {
    return simulate.coreBank.get("unique")(simulate.coreBank.get("join")(x).items);
  });

  defineFunction(simulate, "Intersection", { object: [simulate.varBank, VectorObject], params: [{ name: "Vector 1", needVector: true }, { name: "Vector 2", needVector: true }] }, (x) => {
    let v1 = x[0];
    let v2 = x[1];

    let res = [];

    for (let i = 0; i < v1.items.length; i++) {
      for (let j = 0; j < v2.items.length; j++) {
        if (strictEquals(v1.items[i], v2.items[j])) {
          res.push(v1.items[i]);
          break;
        }
      }
    }
    return simulate.coreBank.get("unique")(res);
  });


  defineFunction(simulate, "Difference", { object: [simulate.varBank, VectorObject], params: [{ name: "Vector 1", needVector: true }, { name: "Vector 2", needVector: true }] }, (x) => {
    let v1 = x[0];
    let v2 = x[1];

    let res = [];

    for (let i = 0; i < v1.items.length; i++) {
      let found = false;
      for (let j = 0; j < v2.items.length; j++) {
        if (strictEquals(v1.items[i], v2.items[j])) {
          found = true;
          break;
        }
      }
      if (!found) {
        res.push(v1.items[i]);
      }
    }
    for (let i = 0; i < v2.items.length; i++) {
      let found = false;
      for (let j = 0; j < v1.items.length; j++) {
        if (strictEquals(v2.items[i], v1.items[j])) {
          found = true;
          break;
        }
      }
      if (!found) {
        res.push(v2.items[i]);
      }
    }

    return simulate.coreBank.get("unique")(res);
  });

  defineFunction(simulate, "Factorial", { params: [{ name: "Number", noUnits: true, leafNeedNum: true }], recurse: true }, (x) => {
    return new Material(factorial(toNum(x[0]).value));
  });

  defineFunction(simulate, "Max", { param: { name: "Items..." }, prep: joinVector }, (x) => {

    let res = x.stackApply((v) => {
      let x = v.items;
      if (x.length > 0) {
        let max = x[0];
        for (let i = 1; i < x.length; i++) {
          if (greaterThan(x[i], max)) {
            max = x[i];
          }
        }
        return max;
      } else {
        throw new ModelError("You must have at least one element to calculate a max.", {
          code: 6017
        });
      }
    });

    return res;
  });
  defineFunction(simulate, "Max", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    return simulate.coreBank.get("max")(x);
  });

  function joinVector(x, notToNum, skip) {
    if (!notToNum) {
      for (let i = 0; i < x.length; i++) {
        x[i] = toNum(x[i]);
      }
    }
    if (x.length === 1 && x[0] instanceof Vector) {
      if (skip) {
        return x[0];
      } else {
        return simulate.coreBank.get("flatten")([x[0]]);
      }
    } else {
      return new Vector(scalarsToVectors(x), simulate);
    }
  }
  function joinArray(x) {
    for (let i = 0; i < x.length; i++) {
      if (x[i].toNum) {
        x[i] = toNum(x[i]);
      }
    }
    if (x.length === 1 && x[0] instanceof Vector) {
      return simulate.coreBank.get("flatten")([toNum(x[0])]).items;
    }
    return joinVector(x, undefined, true).items;
  }
  function scalarsToVectors(x) {
    let needVector = false;
    let vec;

    for (let i = 0; i < x.length; i++) {
      if (x[i] instanceof Vector) {
        vec = x[i];
        needVector = true;
        break;
      }
    }

    if (needVector) {
      for (let i = 0; i < x.length; i++) {
        if (!(x[i] instanceof Vector)) {
          x[i] = replicateVectorStructure(vec, x[i]);
        }
      }
    }

    return x;
  }
  function replicateVectorStructure(vec, val) {
    let v = vec.fullClone();
    for (let i = 0; i < v.items.length; i++) {
      if (v.items[i] instanceof Vector) {
        v.items[i] = replicateVectorStructure(v.items[i], val);
      } else {
        v.items[i] = val;
      }
    }
    return v;
  }

  defineFunction(simulate, "Lookup", { params: [{ name: "Value", noVector: true }, { name: "Value Vector", needVector: true }, { name: "Results Vector", needVector: true }] }, (x) => {
    let v = toNum(x[0]);
    let xVec = toNum(x[1]);
    let yVec = toNum(x[2]);

    if (xVec.items.length !== yVec.items.length) {
      throw new ModelError("The <i>value</i> and <i>results</i> vectors must be the same length", {
        code: 6018
      });
    }

    if (xVec.items.length < 1) {
      throw new ModelError("You must have at least one element in your vectors", {
        code: 6019
      });
    }

    let vec = [];
    for (let i = 0; i < xVec.items.length; i++) {
      vec.push({ x: xVec.items[i], y: yVec.items[i] });
    }

    vec.sort((a, b) => {
      if (greaterThan(a.x, b.x)) {
        return 1;
      } else if (lessThan(a.x, b.x)) {
        return -1;
      } else {
        return 0;
      }
    });

    for (let i = 0; i < vec.length; i++) {
      if (eq(vec[i].x, v)) {
        return vec[i].y.fullClone();
      } else if (greaterThan(vec[i].x, v)) {
        if (i === 0) {
          return vec[i].y.fullClone();
        }

        let dist = minus(vec[i].x, vec[i - 1].x);
        let distLower = minus(v, vec[i - 1].x);
        let distUpper = minus(vec[i].x, v);
        let fLower = div(distUpper, dist);
        let fUpper = div(distLower, dist);
        return plus(mult(vec[i - 1].y, fLower), mult(vec[i].y, fUpper));
      }
    }

    return vec[vec.length - 1].y.fullClone();
  });

  defineFunction(simulate, "Fill", { object: [simulate.varBank, VectorObject], params: [{ name: "Vector", needVector: true }, { name: "Value", allowBoolean: true, allowString: true }] }, (x) => {
    return replicateVectorStructure(x[0], x[1]);
  });

  defineFunction(simulate, "Min", { param: { name: "Items..." }, prep: joinVector },
    /**
     * @param {Vector} x
     * @returns
     */
    (x) => {
      let res = x.stackApply((v) => {
        let x = v.items;
        if (x.length > 0) {
          let min = x[0];
          for (let i = 1; i < x.length; i++) {
            if (lessThan(x[i], min)) {
              min = x[i];
            }
          }
          return min;

        } else {
          throw new ModelError("You must have at least one element to calculate a min.", {
            code: 6020
          });
        }
      });

      return res;
    });
  defineFunction(simulate, "Min", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    return simulate.coreBank.get("min")(x);
  });
  defineFunction(simulate, "Mean", { param: { name: "Items..." }, prep: joinArray },
    /**
     * @param {any[]} x
     * @returns
     */
    (x) => {
      let sum = x[0];
      for (let i = 1; i < x.length; i++) {
        sum = plus(sum, x[i]);
      }
      return div(sum, new Material(x.length));
    });
  defineFunction(simulate, "Mean", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    return simulate.coreBank.get("mean")(x);
  });
  defineFunction(simulate, "Sum", { param: { name: "Items..." }, prep: joinArray },
    /**
     * @param {any[]} x
     * @returns
     */
    (x) => {
      let sum = x[0];

      for (let i = 1; i < x.length; i++) {
        sum = plus(sum, x[i]);
      }

      return sum;
    });
  defineFunction(simulate, "Sum", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    return simulate.coreBank.get("sum")(x);
  });
  defineFunction(simulate, "Product", { param: { name: "Items..." }, prep: joinArray }, (x) => {
    let total = x[0];
    for (let i = 1; i < x.length; i++) {
      total = mult(total, x[i]);
    }
    return total;
  });
  defineFunction(simulate, "Product", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    return simulate.coreBank.get("product")(x);
  });
  defineFunction(simulate, "Median", { param: { name: "Items..." }, prep: joinVector }, (x) => {
    let res = x.stackApply((v) => {
      /** @type {Material[]} */
      let x = simulate.coreBank.get("sort")([v]).items;
      if (x.length > 0) {
        if (Math.floor((x.length - 1) / 2) === (x.length - 1) / 2) {
          return x[(x.length - 1) / 2];
        } else {
          return div(plus(x[Math.floor((x.length - 1) / 2)], x[Math.ceil((x.length - 1) / 2)]), new Material(2));
        }
      } else {
        throw new ModelError("You must have at least one element to calculate a median.", {
          code: 6021
        });
      }
    });
    return res;
  });
  defineFunction(simulate, "Median", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    return simulate.coreBank.get("median")(x);
  });
  defineFunction(simulate, "StdDev", { param: { name: "Items..." }, prep: joinVector }, (x) => {
    let res = x.stackApply((v) => {
      let x = v.items;
      if (x.length > 1) {

        let mean = simulate.coreBank.get("mean")(x);
        let sum = power(minus(x[0], mean), new Material(2));

        for (let i = 1; i < x.length; i++) {
          sum = plus(sum, power(minus(x[i], mean), new Material(2)));
        }
        let r = power(div(sum, new Material(x.length - 1)), new Material(0.5));

        return r;
      } else {
        throw new ModelError("You must have at least two elements to calculate the standard deviation.", {
          code: 6022
        });
      }
    });
    return res;
  });
  defineFunction(simulate, "StdDev", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    return simulate.coreBank.get("stddev")(x);
  });
  defineFunction(simulate, "Correlation", { params: [{ name: "Vector 1", needVector: true }, { name: "Vector 2", needVector: true }] }, (x) => {
    let v1 = toNum(x[0]);
    let v2 = toNum(x[1]);

    if (v1.length() <= 1) {
      throw new ModelError("You must have at least two elements in your vectors to calculate their correlation.", {
        code: 6023
      });
    }
    if (v1.length() !== v2.length()) {
      throw new ModelError("The vectors for Correlation() must be of the same size.", {
        code: 6024
      });
    }


    let v1Mean = simulate.coreBank.get("mean")([v1]);
    let v2Mean = simulate.coreBank.get("mean")([v2]);

    let v1StdDev = simulate.coreBank.get("stddev")([v1]);
    let v2StdDev = simulate.coreBank.get("stddev")([v2]);

    if (v1StdDev.value === 0 || v2StdDev.value === 0) {
      return new Material(0);
    }

    return div(simulate.coreBank.get("sum")([mult(minus(v1.clone(), v1Mean), minus(v2.clone(), v2Mean))]), mult(minus(simulate.coreBank.get("count")([v1]), new Material(1)), mult(v1StdDev, v2StdDev)));
  });
  simulate.varBank.set("count", (x) => {
    x = simulate.coreBank.get("join")(x).items;
    return new Material(x.length);
  });
  simulate.coreBank.set("count", simulate.varBank.get("count"));
  setFunctionDef("Count", {
    allowEmpty: true,
    param: { name: "Items..." }
  });

  simulate.varBank.set("flatten", (x) => {
    let res = flatten(simulate.coreBank.get("join")(x));
    return new Vector(res.items, simulate, res.hasName ? res.names : undefined);
  });
  simulate.coreBank.set("flatten", simulate.varBank.get("flatten"));
  setFunctionDef("Flatten", {
    allowEmpty: true,
    param: { name: "Items..." }
  });

  defineFunction(simulate, "Keys", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    if (!x[0].names) {
      return new Vector([], simulate);
    }
    return new Vector(x[0].names.filter(x => x !== undefined).map(x => stringify(x, simulate)), simulate);
  });
  defineFunction(simulate, "Values", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    return new Vector(x[0].items, simulate);
  });
  defineFunction(simulate, "Length", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    return new Material(x[0].items.length);
  });
  defineFunction(simulate, "Count", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    return new Material(x[0].items.length);
  });
  defineFunction(simulate, "Flatten", { object: VectorObject, params: [{ name: "Vector", needVector: true }] }, (x) => {
    return simulate.coreBank.get("flatten")(x);
  });

  /**
   * @param {Vector} x
   * @returns
   */
  function flatten(x) {
    let res = [];
    let names = [];
    let hasName = undefined;

    for (let i = 0; i < x.length(); i++) {
      if (x.items[i] instanceof Vector) {
        let z = flatten(x.items[i]);
        res = res.concat(z.items);
        names = names.concat(z.names);
        hasName = hasName || z.hasName;
      } else {
        res.push(x.items[i]);
        if (x.names) {
          names.push(x.names[i]);
          hasName = true;
        } else {
          names.push(undefined);
        }
      }
    }
    return { items: res, names: names, hasName: hasName };
  }


  /* Statistics */

  defineFunction(simulate, "CDFNormal", { params: [{ name: "x", noUnits: true, noVector: true }, { name: "Mean", defaultVal: 0, noUnits: true, noVector: true }, { name: "Standard Deviation", defaultVal: 1, noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    let mu = x[1] ? toNum(x[1]).value : 0;
    let sd = x[2] ? toNum(x[2]).value : 1;

    if (sd < 0) {
      throw new ModelError("Standard Deviation must not be negative.", {
        code: 6076
      });
    }

    return new Material(jStat.normal.cdf(val, mu, sd));
  });

  defineFunction(simulate, "PDFNormal", { params: [{ name: "x", noUnits: true, noVector: true }, { name: "Mean", defaultVal: 0, noUnits: true, noVector: true }, { name: "Standard Deviation", defaultVal: 1, noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    let mu = x[1] ? toNum(x[1]).value : 0;
    let sd = x[2] ? toNum(x[2]).value : 1;

    if (sd < 0) {
      throw new ModelError("Standard Deviation must not be negative.", {
        code: 6076
      });
    }

    return new Material(jStat.normal.pdf(val, mu, sd));
  });

  defineFunction(simulate, "InvNormal", { params: [{ name: "p", noUnits: true, noVector: true }, { name: "Mean", defaultVal: 0, noUnits: true, noVector: true }, { name: "Standard Deviation", defaultVal: 1, noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    if (val < 0 || val > 1) {
      throw new ModelError("<i>p</i> is a probability and must be between 0 and 1 inclusive.", {
        code: 6025
      });
    }
    let mu = x[1] ? toNum(x[1]).value : 0;
    let sd = x[2] ? toNum(x[2]).value : 1;

    if (sd < 0) {
      throw new ModelError("Standard Deviation must not be negative.", {
        code: 6076
      });
    }

    return new Material(jStat.normal.inv(val, mu, sd));
  });

  defineFunction(simulate, "CDFLogNormal", { params: [{ name: "x", noUnits: true, noVector: true }, { name: "Mean", defaultVal: 0, noUnits: true, noVector: true }, { name: "Standard Deviation", defaultVal: 1, noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    let mu = x[1] ? toNum(x[1]).value : 0;
    let sd = x[2] ? toNum(x[2]).value : 1;

    if (sd < 0) {
      throw new ModelError("Standard Deviation must not be negative.", {
        code: 6076
      });
    }

    return new Material(jStat.lognormal.cdf(val, mu, sd));
  });

  defineFunction(simulate, "PDFLogNormal", { params: [{ name: "x", noUnits: true, noVector: true }, { name: "Mean", defaultVal: 0, noUnits: true, noVector: true }, { name: "Standard Deviation", defaultVal: 1, noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    let mu = x[1] ? toNum(x[1]).value : 0;
    let sd = x[2] ? toNum(x[2]).value : 1;

    if (sd < 0) {
      throw new ModelError("Standard Deviation must not be negative.", {
        code: 6076
      });
    }

    return new Material(jStat.lognormal.pdf(val, mu, sd));
  });

  defineFunction(simulate, "InvLogNormal", { params: [{ name: "p", noUnits: true, noVector: true }, { name: "Mean", defaultVal: 0, noUnits: true, noVector: true }, { name: "Standard Deviation", defaultVal: 1, noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    if (val < 0 || val > 1) {
      throw new ModelError("<i>p</i> is a probability and must be between 0 and 1 inclusive.", {
        code: 6026
      });
    }
    let mu = x[1] ? toNum(x[1]).value : 0;
    let sd = x[2] ? toNum(x[2]).value : 1;

    if (sd < 0) {
      throw new ModelError("Standard Deviation must not be negative.", {
        code: 6076
      });
    }

    return new Material(jStat.lognormal.inv(val, mu, sd));
  });

  defineFunction(simulate, "CDFt", { params: [{ name: "x", noUnits: true, noVector: true }, { name: "Degrees of Freedom", noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    let dof = toNum(x[1]).value;
    if (dof <= 0) {
      throw new ModelError("<i>Degrees of Freedom</i> must be greater than 0.", {
        code: 6027
      });
    }

    return new Material(jStat.studentt.cdf(val, dof));
  });

  defineFunction(simulate, "PDFt", { params: [{ name: "x", noUnits: true, noVector: true }, { name: "Degrees of Freedom", noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    let dof = toNum(x[1]).value;
    if (dof <= 0) {
      throw new ModelError("<i>Degrees of Freedom</i> must be greater than 0.", {
        code: 6028
      });
    }

    return new Material(jStat.studentt.pdf(val, dof));
  });

  defineFunction(simulate, "Invt", { params: [{ name: "p", noUnits: true, noVector: true }, { name: "Degrees of Freedom", noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    if (val < 0 || val > 1) {
      throw new ModelError("<i>p</i> is a probability and must be between 0 and 1 inclusive.", {
        code: 6029
      });
    }
    let dof = toNum(x[1]).value;
    if (dof <= 0) {
      throw new ModelError("<i>Degrees of Freedom</i> must be greater than 0.", {
        code: 6030
      });
    }

    return new Material(jStat.studentt.inv(val, dof));
  });

  defineFunction(simulate, "CDFF", { params: [{ name: "x", noUnits: true, noVector: true }, { name: "Degrees of Freedom 1", noUnits: true, noVector: true }, { name: "Degrees of Freedom 2", noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    let dof1 = toNum(x[1]).value;
    if (dof1 <= 0) {
      throw new ModelError("<i>Degrees of Freedom</i> must be greater than 0.", {
        code: 6031
      });
    }
    let dof2 = toNum(x[2]).value;
    if (dof2 <= 0) {
      throw new ModelError("<i>Degrees of Freedom</i> must be greater than 0.", {
        code: 6032
      });
    }

    return new Material(jStat.centralF.cdf(val, dof1, dof2));
  });

  defineFunction(simulate, "PDFF", { params: [{ name: "x", noUnits: true, noVector: true }, { name: "Degrees of Freedom 1", noUnits: true, noVector: true }, { name: "Degrees of Freedom 2", noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    let dof1 = toNum(x[1]).value;
    if (dof1 <= 0) {
      throw new ModelError("<i>Degrees of Freedom 1</i> must be greater than 0.", {
        code: 6033
      });
    }
    let dof2 = toNum(x[2]).value;
    if (dof2 <= 0) {
      throw new ModelError("<i>Degrees of Freedom 2</i> must be greater than 0.", {
        code: 6034
      });
    }

    return new Material(jStat.centralF.pdf(val, dof1, dof2));
  });

  defineFunction(simulate, "InvF", { params: [{ name: "p", noUnits: true, noVector: true }, { name: "Degrees of Freedom 1", noUnits: true, noVector: true }, { name: "Degrees of Freedom 2", noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    if (val < 0 || val > 1) {
      throw new ModelError("<i>p</i> is a probability and must be between 0 and 1 inclusive.", {
        code: 6035
      });
    }
    let dof1 = toNum(x[1]).value;
    if (dof1 <= 0) {
      throw new ModelError("<i>Degrees of Freedom 1</i> must be greater than 0.", {
        code: 6036
      });
    }
    let dof2 = toNum(x[2]).value;
    if (dof2 <= 0) {
      throw new ModelError("<i>Degrees of Freedom</i> must be greater than 0.", {
        code: 6037
      });
    }

    return new Material(jStat.centralF.inv(val, dof1, dof2));
  });

  defineFunction(simulate, "CDFChiSquared", { params: [{ name: "x", noUnits: true, noVector: true }, { name: "Degrees of Freedom", noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    let dof = toNum(x[1]).value;
    if (dof <= 0) {
      throw new ModelError("<i>Degrees of Freedom</i> must be greater than 0.", {
        code: 6038
      });
    }

    return new Material(jStat.chisquare.cdf(val, dof));
  });

  defineFunction(simulate, "PDFChiSquared", { params: [{ name: "x", noUnits: true, noVector: true }, { name: "Degrees of Freedom", noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    let dof = toNum(x[1]).value;
    if (dof <= 0) {
      throw new ModelError("<i>Degrees of Freedom</i> must be greater than 0.", {
        code: 6039
      });
    }

    return new Material(jStat.chisquare.pdf(val, dof));
  });

  defineFunction(simulate, "InvChiSquared", { params: [{ name: "p", noUnits: true, noVector: true }, { name: "Degrees of Freedom", noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    if (val < 0 || val > 1) {
      throw new ModelError("<i>p</i> is a probability and must be between 0 and 1 inclusive.", {
        code: 6040
      });
    }
    let dof = toNum(x[1]).value;
    if (dof <= 0) {
      throw new ModelError("<i>Degrees of Freedom</i> must be greater than 0.", {
        code: 6041
      });
    }

    return new Material(jStat.chisquare.inv(val, dof));
  });


  defineFunction(simulate, "CDFExponential", { params: [{ name: "x", noUnits: true, noVector: true }, { name: "Rate", noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    let rate = toNum(x[1]).value;
    if (rate <= 0) {
      throw new ModelError("<i>Rate</i> must be greater than 0.", {
        code: 6042
      });
    }

    return new Material(jStat.exponential.cdf(val, rate));
  });

  defineFunction(simulate, "PDFExponential", { params: [{ name: "x", noUnits: true, noVector: true }, { name: "Rate", noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    let rate = toNum(x[1]).value;
    if (rate <= 0) {
      throw new ModelError("<i>Rate</i> must be greater than 0.", {
        code: 6043
      });
    }

    return new Material(jStat.exponential.pdf(val, rate));
  });

  defineFunction(simulate, "InvExponential", { params: [{ name: "p", noUnits: true, noVector: true }, { name: "Rate", noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    if (val < 0 || val > 1) {
      throw new ModelError("<i>p</i> is a probability and must be between 0 and 1 inclusive.", {
        code: 6044
      });
    }
    let rate = toNum(x[1]).value;
    if (rate <= 0) {
      throw new ModelError("<i>Rate</i> must be greater than 0.", {
        code: 6045
      });
    }

    return new Material(jStat.exponential.inv(val, rate));
  });

  defineFunction(simulate, "CDFPoisson", { params: [{ name: "x", noUnits: true, noVector: true }, { name: "Lambda", noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    let Lambda = toNum(x[1]).value;
    if (Lambda < 0) {
      throw new ModelError("<i>Lambda</i> must be greater than or equal to 0.", {
        code: 6046
      });
    }

    return new Material(jStat.poisson.cdf(val, Lambda));
  });

  defineFunction(simulate, "PMFPoisson", { params: [{ name: "x", noUnits: true, noVector: true }, { name: "Lambda", noUnits: true, noVector: true }] }, (x) => {
    let val = toNum(x[0]).value;
    let Lambda = toNum(x[1]).value;
    if (Lambda < 0) {
      throw new ModelError("<i>Lambda</i> must be greater than or equal to 0.", {
        code: 6047
      });
    }

    return new Material(jStat.poisson.pdf(val, Lambda));
  });



  /* End Statistics */



  defineFunction(simulate, "SetRandSeed", { params: [{ name: "Seed Number", noUnits: true, noVector: true }] }, (x) => {
    simulate.random = SeedRandom.seedrandom(toNum(x[0]).value);
    return stringify("Random Seed Set", simulate);
  });

  defineFunction(simulate, "Alert", { params: [{ name: "Message", allowString: true, allowBoolean: true }] }, (x) => {
    if (typeof alert === "undefined") {
      throw new ModelError("Alert() is not implemented on this platform.", {
        code: 6048
      });
    }

    alert(x[0]);
    return new Material(1);
  });

  defineFunction(simulate, "Console", { params: [{ name: "Message", allowString: true, allowBoolean: true }], complete: false }, (x) => {
    console.log(x[0]);
    return new Material(1);
  });

  defineFunction(simulate, "Prompt", { params: [{ name: "Message", allowString: true, allowBoolean: true }, { name: "Default", defaultVal: "''", allowString: true, allowBoolean: true }] }, (x) => {
    if (typeof prompt === "undefined") {
      throw new ModelError("Prompt() is not implemented on this platform.", {
        code: 6049
      });
    }

    let y = x[1];

    if (y instanceof Material && !y.units) {
      y = y.value;
    }

    let result = prompt(x[0], y);

    if (result === null) {
      return new Material(0);
    } else if (parseFloat(result).toString() === result) {
      return new Material(parseFloat(result));
    } else {
      return stringify(result, simulate);
    }
  });

  defineFunction(simulate, "Confirm", { params: [{ name: "Message", allowString: true, allowBoolean: true }] }, (x) => {

    if (typeof confirm === "undefined") {
      throw new ModelError("Confirm() is not implemented on this platform.", {
        code: 6050
      });
    }


    return confirm(x[0]);
  });

  defineFunction(simulate, "Parse", { object: StringObject, params: [{ name: "String", allowString: true }] }, (x) => {
    let res = parseFloat(x[0]);

    if (isNaN(res)) {
      throw new ModelError(`"${x[0]}" is not a number.`, {
        code: 6091
      });
    }

    return new Material(res);
  });

  defineFunction(simulate, "Split", { object: StringObject, params: [{ name: "String", needString: true }, { name: "Splitter", needString: true }] }, (x) => {
    return stringify(new Vector(x[0].split(x[1]), simulate), simulate);
  });

  defineFunction(simulate, "Join", { object: VectorObject, params: [{ name: "Vector", needVector: true }, { name: "Joiner", needString: true }] }, (x) => {
    return stringify(x[0].items.join(x[1]), simulate);
  });

  defineFunction(simulate, "Trim", { object: StringObject, params: [{ name: "String", needString: true }], recurse: true }, (x) => {
    return stringify(x[0].trim(), simulate);
  });

  defineFunction(simulate, "Range", { object: StringObject, params: [{ name: "String", needString: true }, { name: "Indexes", noUnits: true }] }, (x) => {
    function validateStringRangeIndex(index) {
      if (!Number.isInteger(index)) {
        throw new ModelError(`Range() indexes must be integers, got ${index}.`, {
          code: 6083
        });
      }
      if (index < 1 || index > x[0].length) {
        throw new ModelError(`Range() index out of range, must be between 1 and ${x[0].length}. Got ${index}.`, {
          code: 6084
        });
      }
      return index;
    }

    if (x[1] instanceof Vector) {
      let res = "";
      for (let i = 0; i < x[1].items.length; i++) {
        res += x[0].charAt(validateStringRangeIndex(toNum(x[1].items[i]).value) - 1);
      }
      return stringify(res, simulate);
    } else {
      return stringify(x[0].charAt(validateStringRangeIndex(toNum(x[1]).value) - 1), simulate);
    }
  });

  defineFunction(simulate, "Length", { object: StringObject, params: [{ name: "String", needString: true }] }, (x) => {
    return new Material(x[0].length);
  });

  defineFunction(simulate, "IndexOf", { object: StringObject, params: [{ name: "Haystack", needString: true }, { name: "Needle", needString: true }] }, (x) => {
    return new Material(x[0].indexOf(x[1]) + 1);
  });

  defineFunction(simulate, "Contains", { object: StringObject, params: [{ name: "Haystack", needString: true }, { name: "Needle", needString: true }] }, (x) => {
    return !eq(StringObject["indexof"](x), new Material(0));
  });

  defineFunction(simulate, "Lowercase", { object: StringObject, params: [{ name: "String", needString: true }] }, (x) => {
    return stringify(x[0].toLowerCase(), simulate);
  });

  defineFunction(simulate, "Uppercase", { object: StringObject, params: [{ name: "String", needString: true }] }, (x) => {
    return stringify(x[0].toUpperCase(), simulate);
  });

  simulate.coreBank.set("stringbase", makeObjectBase(StringObject, simulate));
  simulate.varBank.set("stringbase", simulate.coreBank.get("stringbase"));
  simulate.coreBank.set("vectorbase", makeObjectBase(VectorObject, simulate));
  simulate.varBank.set("vectorbase", simulate.coreBank.get("vectorbase"));
}


/**
 * @param {*} x
 * @param {import("../Simulator").Simulator} simulate
 *
 * @returns
 */
export function makeObjectBase(x, simulate) {
  let names = Object.keys(x);
  let items = [];
  for (let name of names) {
    items.push(objectizeFunction(x[name]));
  }
  let vec = new Vector(items, simulate, names);
  vec.parent = undefined;
  return vec;
}


/**
 * @typedef {Object} DefineFunctionParam
 * @property {string} name
 * @property {any=} defaultVal
 * @property {boolean=} noUnits
 * @property {boolean=} noVector
 * @property {boolean=} needVector
 * @property {boolean=} needNum
 * @property {boolean=} leafNeedNum
 * @property {boolean=} vectorize
 * @property {boolean=} allowBoolean
 * @property {boolean=} allowString
 * @property {boolean=} needString
 * @property {boolean=} needPrimitive
 * @property {boolean=} allowOptionalPrimitive
 * @property {boolean=} needAgent
 * @property {boolean=} needAgents
 * @property {boolean=} needPopulation
 * @property {boolean=} implicitFunction
 * @property {{ name: string }[]=} injectedVariables
 * @property {boolean=} silentDefault - don't show defaultVal in function signature, don't show the parameter at all unless the user specifies it
 */


/**
 * @callback DefineFunctionPrep
 * @param {any[]} args
 * @returns {any}
 */

/**
 * @typedef {{ param: DefineFunctionParam, allowEmpty?: boolean, prep?: DefineFunctionPrep, object?: any, complete?: boolean }|{ params: DefineFunctionParam[], recurse?: boolean, prep?: DefineFunctionPrep, object?: any, complete?: boolean }} DefineFunctionDefinition
 */


/** @typedef {Map<string, {name: string, standardFnName: string, objectFnName: string, definition: DefineFunctionDefinition }>} FunctionDefItem */

export let functionDefs = {
  topLevel: /** @type {FunctionDefItem} */ (new Map()),
  string: /** @type {FunctionDefItem} */ (new Map()),
  vector: /** @type {FunctionDefItem} */ (new Map()),
  primitive: /** @type {FunctionDefItem} */ (new Map()),
  agent: /** @type {FunctionDefItem} */ (new Map())
};

/**
 * @param {DefineFunctionDefinition} definition
 * @returns
 */
function bucketsForDefinition(definition) {
  const buckets = new Set();

  const targets = !definition.object
    ? [null]
    : Array.isArray(definition.object)
      ? definition.object
      : [definition.object];

  for (const target of targets) {
    if (target == null) {
      buckets.add("topLevel");
    } else if (target instanceof Map) {
      buckets.add("topLevel");
    } else {
      buckets.add(target._object_type);
    }
  }
  return buckets;
}


/**
 * @param {string} name
 * @param {DefineFunctionDefinition} definition
 */
export function setFunctionDef(name, definition) {
  let standardFnName;
  let objectFnName;

  if ("params" in definition) {
    standardFnName = name + "(" + definition.params.map((x) => {
      return x.name + ("defaultVal" in x ? "=" + x.defaultVal.toString() : "");
    }).join(", ") + ")";
    objectFnName = name + "(" + definition.params.slice(1).map((x) => {
      return x.name + ("defaultVal" in x ? "=" + x.defaultVal.toString() : "");
    }).join(", ") + ")";
  } else {
    let paramName = definition.param.name;
    standardFnName = name + "(" + paramName + ")";
    objectFnName = name + "(" + paramName + ")";
  }

  const res = {
    name,
    standardFnName,
    objectFnName,
    definition
  };

  const key = name.toLowerCase();
  for (const bucket of bucketsForDefinition(definition)) {
    functionDefs[bucket].set(key, res);
  }

  return res;
}


/**
 * @param {import("../Simulator").Simulator} simulate
 * @param {string} name
 * @param {DefineFunctionDefinition} definition
 * @param {function} fn
 */
export function defineFunction(simulate, name, definition, fn) {
  let def = setFunctionDef(name, definition);

  const arr = "params" in definition;

  let vectorized = [];


  let requiredLength = undefined;
  if (arr) {
    requiredLength = definition.params.length;
    for (let i = 0; i < definition.params.length; i++) {
      if ("defaultVal" in definition.params[i]) {
        requiredLength = i;
        break;
      }
    }

    for (let i = 0; i < definition.params.length; i++) {
      if (definition.params[i].vectorize) {
        vectorized.push(i);
        if (definition.params[i].noVector) {
          throw new ModelError(`Cannot have a non-vector vectorized parameter. Function '${name}', parameter '${definition.params[i].name}'.`, {
            code: 6051
          });
        }
      }
    }
  }




  let f = function (x, id, _ls, config = {}) {
    let fnName;
    if (config.isObjectCaller) {
      // e.g. [test].x()
      fnName = def.objectFnName;
    } else {
      // e.g. x([test])
      fnName = def.standardFnName;
    }

    if (definition.prep) {
      x = definition.prep(x);
    }

    if (arr) {
      if ((x.length > definition.params.length || x.length < requiredLength)) {
        throw new ModelError(`Wrong number of parameters for ${fnName}.`, {
          code: 6052
        });
      }
    } else {
      if (!x.length && !definition.allowEmpty) {
        throw new ModelError(`At least one parameter required for ${name}().`, {
          code: 6053
        });
      }
    }

    for (let i = 0; i < x.length; i++) {
      let config = arr ? definition.params[i] : definition.param;

      function simplify(param) {
        if (param instanceof UserFunction) {
          return simplify(param.fn([]));
        }
        if (!config.needPrimitive && !config.allowOptionalPrimitive && !config.needAgent && !config.needPopulation) {
          if (param instanceof SPrimitive && !(param instanceof SPopulation)) {
            return simplify(toNum(param));
          }
        }
        return param;
      }
      x[i] = simplify(x[i]);

      if (config.noUnits) {
        let unitCheck = (z) => {
          if (z && (toNum(z) instanceof Material) && toNum(z).units && !toNum(z).units.isUnitless()) {
            throw new ModelError(`${fnName} does not accept units for the parameter '${config.name}'. Got units of <i>${toNum(z).units.toString()}</i>`, {
              code: 6054
            });
          }
        };
        if (x[i] instanceof Vector) {
          x[i].recurseEach(unitCheck);
        } else {
          unitCheck(x[i]);
        }
      }
      if (config.noVector && x[i] instanceof Vector) {
        throw new ModelError(`${fnName} does not accept vectors for the parameter '${config.name}'.`, {
          code: 6055
        });
      }
      if (config.vectorize && x[i] instanceof Vector && !x[i].names) {
        throw new ModelError(`${fnName} does not accepted non-named vectors for the parameter '${config.name}'.`, {
          code: 6056
        });
      }
      if (config.needVector) {
        if (x[i] instanceof SPrimitive) {
          x[i] = toNum(x[i]);
        }
        if (!(x[i] instanceof Vector)) {
          throw new ModelError(`${fnName} requires a vector for the parameter '${config.name}'.`, {
            code: 6057
          });
        }
      }
      if (config.needNum) {
        if (x[i] instanceof SPrimitive) {
          x[i] = toNum(x[i]);
        }
        if (!(x[i] instanceof Material)) {
          throw new ModelError(`${fnName} requires a number for the parameter '${config.name}'.`, {
            code: 6058
          });
        }
      }
      if (config.needPrimitive && !(x[i] instanceof SPrimitive)) {
        throw new ModelError(`${fnName} requires a primitive for the parameter '${config.name}'.`, {
          code: 6059
        });
      }
      if (!config.allowBoolean && typeof x[i] === "boolean") {
        throw new ModelError(`${fnName} does not accept boolean values for the parameter '${config.name}'.`, {
          code: 6060
        });
      }
      if (config.needAgent && !(x[i] instanceof SAgent)) {
        x[i] = agent(x[i], simulate);
      }
      if (config.needString) {
        if (!(typeof x[i] === "string" || x[i] instanceof String)) {
          throw new ModelError(`${fnName} requires a string for the parameter '${config.name}'.`, {
            code: 6061
          });
        }
      }
      if (!config.allowString && !config.needString
        && (typeof x[i] === "string" || x[i] instanceof String)) {
        throw new ModelError(`${fnName} does not accept string values for the parameter '${config.name}'.`, {
          code: 6062
        });
      }
      if (config.needAgents && !(x[i] instanceof SPopulation)) {
        x[i] = agents(x[i]);
      }
      if (config.needPopulation && !(x[i] instanceof Vector)) {
        x[i] = getPopulation(x[i], simulate);
      }
    }
    let q;
    if (arr && definition.recurse) {
      q = toNum(x[0]);
      if (definition.params[0] && definition.params[0].leafNeedNum) {
        if (!(q instanceof Vector)) {
          if (!(q instanceof Material)) {
            throw new ModelError(`${fnName} requires a number for the parameter '${definition.params[0].name}'.`, {
              code: 6058
            });
          }
        }
      }
    }
    if (arr && definition.recurse && q instanceof Vector) {
      return q.cloneApply((z) => {
        if (!(z instanceof Vector) && definition.params[0] && definition.params[0].leafNeedNum) {
          if (!(z instanceof Material)) {
            throw new ModelError(`${fnName} requires a number for the parameter '${definition.params[0].name}'.`, {
              code: 6058
            });
          }
        }
        return f([z].concat(x.slice(1)), id);
      });
    } else if (arr && vectorized.length > 0) {
      // Auto-vectorize the inner function

      let base = undefined, baseI = -1;
      for (let i = 0; i < vectorized.length; i++) {
        if (x[vectorized[i]]) {
          let v = toNum(x[vectorized[i]]);
          if (v instanceof Vector && v.namesLC) {
            if (!base) {
              base = v;
              baseI = vectorized[i];
            } else {
              if (!base.keysMatch(v.namesLC)) {
                throw new ModelError(`Vector keys do not match between parameters '${definition.params[baseI].name}' and '${definition.params[vectorized[i]].name}' in ${fnName}.`, {
                  code: 6064
                });
              }
            }
          }
        }
      }

      if (!base) {
        // Nothing is vectorized, we can behave normally
        return fn(x, id);
      } else {
        // We need to vectorize
        let keys = base.namesLC;
        let res = [];
        for (let i = 0; i < keys.length; i++) {
          let newX = [];
          for (let j = 0; j < x.length; j++) {
            if (vectorized.indexOf(j) === -1) {
              newX.push(x[j]);
            } else {
              let v = toNum(x[j]);
              if (v instanceof Vector && v.namesLC) {
                newX.push(v.select([keys[i]]));
              } else {
                newX.push(v);
              }

            }
          }
          let z = fn(newX, id);
          if (z instanceof Vector) {
            if (!base.keysMatch(z.namesLC)) {
              throw new ModelError(`Vector keys do not match between parameter '${definition.params[baseI].name}' and calculation result.`, {
                code: 6065
              });
            }

            res.push(z.select([keys[i]]));
          } else {
            res.push(z);
          }
        }
        return new Vector(res, simulate, keys);
      }


    } else {
      return fn(x, id);
    }
  };

  if (!definition.object) {
    simulate.varBank.set(name.toLowerCase(), f);
    simulate.coreBank.set(name.toLowerCase(), f);
  } else {
    if (definition.object instanceof Array) {
      for (let i = 0; i < definition.object.length; i++) {
        if (definition.object[i] instanceof Map) {
          if (definition.object[i] === simulate.varBank) {
            simulate.coreBank.set(name.toLowerCase(), f);
          }
          definition.object[i].set(name.toLowerCase(), f);
        } else {
          definition.object[i][name.toLowerCase()] = f;

        }
      }
    } else {
      if (definition.object instanceof Map) {
        definition.object.set(name.toLowerCase(), f);
      } else {
        definition.object[name.toLowerCase()] = f;
      }
    }
  }

  if (arr && definition.recurse) {
    VectorObject[name.toLowerCase()] = f;
  }
}


function objectizeFunction(fn) {
  let f = function (x, fingerprint, lastSelf) {
    if (!lastSelf) {
      throw new ModelError("Object function not used on object", {
        code: 6066
      });
    }
    return fn([lastSelf].concat(x), fingerprint, lastSelf, {
      isObjectCaller: true
    });
  };
  f.delayEvalParams = fn.delayEvalParams;
  return f;
}


/**
 * @param {number} x
 * @returns {number}
 */
function factorial(x) {
  if (Math.round(x) !== x) {
    throw new ModelError("The factorial() function only accepts integers.", {
      code: 6067
    });
  } else if (x < 0) {
    throw new ModelError("The factorial() function is only defined for integers 0 or larger.", {
      code: 6068
    });
  }
  if (x > 1) {
    return x * factorial(x - 1);
  } else {
    return 1;
  }
}


export function testArgumentsSize(x, name, min, max) {
  if (x.length < min || x.length > max) {
    throw new ModelError(`Wrong number of parameters for ${name}().`, {
      code: 6069
    });
  }
}
